#файлы баз данных
db_path = 'DB/bot_database.db'
themes_path = 'DB/themes_database.db'

#токен телеграм бота
token = '7061627509:AAHBnrjShDnKPw7dGf-c4La4PQU46DDCSrQ'

#для gigachat
RqUID = 'ee5de75e-44c9-4356-890e-7e3eec44be2d'
AUTHORIZATION = 'YjMwZWVjZGItYThhZi00N2M3LThlNjgtNjdiOGE1ZGIzMjI4OmVlNWRlNzVlLTQ0YzktNDM1Ni04OTBlLTdlM2VlYzQ0YmUyZA=='

#префикс для промпта в нейросеть
#preqtext = 'действуй как финансовый советник. дай совет. в совете отрази вопрос:  '
#preqtext = 'напиши короткий совет, уберись в 300 симолов. ответ напиши без предисловия.  '
preqtext = 'напиши короткий совет в стиле Чендлера Бинга.  '



#заглушка для промпта. нужна пока не будет реализован выбор темы из базы
#qtext = 'Действуй как финансовый советник. дай короткий совет, не больше 300 символов. в совете отрази вопрос:  Как установить реалистичные финансовые цели?'